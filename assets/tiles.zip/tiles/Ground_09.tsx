<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ground_09" tilewidth="264" tileheight="264" tilecount="1" columns="1">
 <image source="../images/Sprites/14-TileSets/Ground_09.png" width="265" height="265"/>
</tileset>
