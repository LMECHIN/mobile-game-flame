<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground" tilewidth="264" tileheight="264" tilecount="9" columns="3">
 <image source="../images/Sprites/14-TileSets/ground.png" trans="ff00ff" width="792" height="792"/>
</tileset>
