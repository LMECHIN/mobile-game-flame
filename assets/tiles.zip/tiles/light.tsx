<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="light" tilewidth="264" tileheight="264" tilecount="9" columns="3">
 <image source="../images/Sprites/14-TileSets/light.png" trans="000000" width="792" height="792"/>
</tileset>
