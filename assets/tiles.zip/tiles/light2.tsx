<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="light2" tilewidth="264" tileheight="264" tilecount="9" columns="3">
 <image source="../images/Sprites/14-TileSets/light2.png" trans="000000" width="795" height="792"/>
</tileset>
