<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Obstacle_01" tilewidth="264" tileheight="264" tilecount="9" columns="3">
 <image source="../images/Sprites/14-TileSets/Obstacle_01.png" width="795" height="795"/>
</tileset>
