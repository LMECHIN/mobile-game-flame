<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="Pixel Game" tilewidth="32" tileheight="32" tilecount="247" columns="19">
 <image source="../images/Sprites/14-TileSets/Terrain (32x32).png" width="608" height="416"/>
</tileset>
