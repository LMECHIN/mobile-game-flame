<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground_use" tilewidth="264" tileheight="264" tilecount="16" columns="4">
 <image source="../images/Sprites/14-TileSets/ground_use.png" width="1056" height="1056"/>
</tileset>
