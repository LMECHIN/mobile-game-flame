<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="Ground_13" tilewidth="264" tileheight="264" tilecount="1" columns="1">
 <image source="../images/Sprites/14-TileSets/Ground_13.png" trans="ff00ff" width="265" height="265"/>
</tileset>
