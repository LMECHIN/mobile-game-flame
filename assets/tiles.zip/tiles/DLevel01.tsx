<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="Decorations (32x32)" tilewidth="32" tileheight="32" tilecount="42" columns="7">
 <image source="../images/Sprites/14-TileSets/Decorations (32x32).png" width="224" height="192"/>
</tileset>
